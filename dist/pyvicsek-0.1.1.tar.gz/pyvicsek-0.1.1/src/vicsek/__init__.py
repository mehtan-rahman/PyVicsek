from vicsek.models.vicsek import Vicsek
from vicsek.models.heterogeneous import HeterogeneousVicsek

from vicsek.util.factory import initialize_random_particles
